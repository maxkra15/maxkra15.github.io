Visual presentation source (MIT)

Extract these files into the published report directory, alongside data/ and figures/.
Run: uv run --no-project --with matplotlib python render_visual_report.py

The renderer uses data/measurements.json and preserves all measured evidence.
The first run archives the original index.html as appendix.html. Further runs keep it.
Original data/provenance.json refers to that archived presentation; data/presentation.json
records the new renderer and input hashes. SHA256SUMS covers the current published files.
The three original measured/publisher source ZIPs are separate, unchanged snapshots.
