Visual presentation source (MIT)

Extract these files into the published report directory, alongside data/ and figures/.
Run: uv run --no-project --with matplotlib python render_visual_report.py

The renderer reads data/measurements.json plus data/measurements-8192.json and their raw records.
It preserves historical evidence, selects rollout/learning cases, and builds the current appendix.
plot_report.py generates scaling, paired RGB-cost and per-seed learning figures.
Original data/provenance.json refers to original-report.html; data/presentation.json
records the new renderer and input hashes. SHA256SUMS covers the current published files.
The three original measured/publisher source ZIPs are separate, unchanged snapshots.
