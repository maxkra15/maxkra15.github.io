"""Run approved untimed high-index audits after both scaling suites have stopped."""

from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import threading
import time

BASE = Path('/home/horde/simulator-comparison-20261105')
SCRIPT_SHA = 'a8cc760abdedc0334a5052321f68e53c38fd3662cf32119d1e398f75922e13da'
PINS = {
    'isaaclab': 'efa240ec39794f5d80430cbe38620626954c2c4d',
    'genesis': '969c3bd1449d0f0c79effd7b6a72614ed46ba6e7',
    'newton': '42f7def118c2c4299ce493457bafd4e8a22a696e',
}
SPECS = {
    'baseline': (BASE, '1', 'ba2a7c83-f6f7-e887-63a0-09a770a9122a', ['anymal', 'cartpole'], '2026-11-06-rollout-8192', '2579e4ca836e956784261e09b0e193d63e40d96742ed5b305a76daf0e33970af'),
    'franka': (BASE / 'franka-extension', '0', '6b0d678c-e620-c957-931d-e2308d31bb87', ['franka'], '2026-11-06-rollout-8192-franka', '634c1fcc57ac70c130f95b36899d8f2fa7e1484d1db21ca8bdbab7c3b3669cc4'),
}


def main(cohort):
    # Refuse an accidental overlap even if the caller launches the controller early.
    for name, (checkout, _, _, tasks, folder, _) in SPECS.items():
        output = checkout / '.benchmark_results' / folder
        summary = json.loads((output / 'suite.summary.json').read_text())
        count = len(tasks) * 6
        assert summary == {'expected_runs': count, 'successful_runs': count, 'unsuccessful_runs': 0}, (name, summary)
        pid = int((output / 'suite.pid').read_text())
        process = Path(f'/proc/{pid}/stat')
        assert not process.exists() or process.read_text().split()[2] == 'Z', pid
    checkout, gpu, uuid, tasks, folder, harness_sha = SPECS[cohort]
    harness = checkout / 'scripts/benchmarks/simulator_comparison'
    output = checkout / '.benchmark_results' / folder
    audit_root = BASE / '.benchmark_results/2026-11-06-rollout-8192-validation'
    script = audit_root / '8192-scale-audit.py'
    assert hashlib.sha256(script.read_bytes()).hexdigest() == SCRIPT_SHA
    sys.path.insert(0, str(harness))
    from suite import active_compute, monitor_gpu

    os.environ.update(CUDA_VISIBLE_DEVICES=gpu, OMP_NUM_THREADS='8', OPENBLAS_NUM_THREADS='8', MKL_NUM_THREADS='8', PYGLET_HEADLESS='1', PYOPENGL_PLATFORM='egl', OMNI_KIT_ACCEPT_EULA='YES', ISAACSIM_ACCEPT_EULA='Y')
    paths = [str(harness), *(str(p) for p in (checkout / 'source').iterdir() if p.is_dir())]
    for task in tasks:
        for backend in ['genesis', 'isaaclab']:
            matches = list(output.glob(f'{backend}-{task}-rollout-none-8192-s0-*/config.json'))
            assert len(matches) == 1, matches
            config = matches[0]
            environment = os.environ.copy()
            environment['PYTHONPATH'] = os.pathsep.join(([str(checkout / '.benchmark_sources/genesis')] if backend == 'genesis' else []) + paths)
            interpreter = BASE / f'.benchmark_sources/{"genesis_env" if backend == "genesis" else "mjwarp_env"}/bin/python'
            destination = audit_root / cohort / f'{backend}-{task}' / 'attempt-1'
            destination.mkdir(parents=True, exist_ok=False)
            argv = [str(interpreter), str(script), '--config', str(config), '--output', str(destination / 'audit.json')]
            while active_compute():
                print(json.dumps({'event': 'audit_waiting', 'cohort': cohort, 'backend': backend, 'task': task}), flush=True)
                time.sleep(5)
            print(json.dumps({'event': 'audit_start', 'cohort': cohort, 'backend': backend, 'task': task}), flush=True)
            with (destination / 'stdout.log').open('xb') as stream:
                process = subprocess.Popen(argv, cwd=checkout, env=environment, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
                samples = []
                stop = threading.Event()
                monitor = threading.Thread(target=monitor_gpu, args=(process.pid, stop, samples), daemon=True)
                monitor.start()
                try:
                    returncode = process.wait(timeout=3600)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    returncode = process.wait()
                finally:
                    stop.set()
                    monitor.join(timeout=5)
            result = json.loads((destination / 'audit.json').read_text())
            recorded = result['provenance']
            checks = {
                'returncode_zero': returncode == 0,
                'audit_passed': result['status'] == 'ok' and len(result['checks']) == 4 and all(item['passed'] for item in result['checks'].values()),
                'script_sha256_matches': result['audit_sha256'] == SCRIPT_SHA,
                'config_sha256_matches': result['config_sha256'] == hashlib.sha256(config.read_bytes()).hexdigest(),
                'config_exact': result['config'] == json.loads(config.read_text()),
                'device_matches': recorded['cuda_device_uuid'] == uuid and recorded['cuda_visible_devices'] == gpu,
                'runtime_matches': recorded['harness_sha256'] == harness_sha and recorded['torch'] == '2.11.0+cu130' and recorded['torch_cuda'] == '13.0',
            }
            required = ['genesis'] if backend == 'genesis' else ['isaaclab', 'newton']
            checks['actual_loaded_heads_match'] = all(recorded['loaded_packages'].get(name, {}).get('git_head') == PINS[name] for name in required)
            raw_result = config.parent / 'run.result.json'
            measured = json.loads(raw_result.read_text())['provenance']['runtime']['source_packages']
            checks['actual_loaded_paths_match'] = all(Path(recorded['loaded_packages'][name]['path']).resolve() == Path(measured[name]).resolve() for name in required)
            checks['selected_gpu_uncontended'] = not any(sample['external_compute'] for sample in samples)
            if backend == 'isaaclab':
                diagnostics = result['backend_diagnostics_after_index_audit']
                checks['native_graph_active_at_end'] = diagnostics['graph_active'] is True
                checks['native_fatal_capacity_clear_at_end'] = not any(diagnostics['fatal_capacity_flags_at_end'])
            receipt = {'kind': 'batch_scale_execution_receipt', 'cohort': cohort, 'backend': backend, 'task': task, 'argv': argv, 'raw_config': str(config), 'raw_result': str(raw_result), 'raw_result_sha256': hashlib.sha256(raw_result.read_bytes()).hexdigest(), 'script_sha256': SCRIPT_SHA, 'returncode': returncode, 'checks': checks, 'selected_gpu_activity_samples': samples}
            (destination / 'execution.json').write_text(json.dumps(receipt, indent=2) + '\n')
            print(json.dumps({'event': 'audit_finished', 'cohort': cohort, 'backend': backend, 'task': task, 'checks': checks, 'path': str(destination / 'audit.json')}), flush=True)
            assert all(checks.values()), receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('cohort', choices=SPECS)
    main(parser.parse_args().cohort)
